import { ArrowLeft, MessageCircle, Phone } from "lucide-react";
import logoImage from "@/assets/lets-face-it-logo-transparent.png";

const phoneNumber = "8168042701";
const displayPhone = "816-804-2701";

const Contact = () => {
  return (
    <main className="min-h-screen bg-soft-gradient px-5 py-8 lg:px-8">
      <nav className="mx-auto flex max-w-6xl items-center justify-between">
        <a href="/" aria-label="Back to home" className="flex items-center gap-3">
          <img src={logoImage} alt="Let's Face It With Chelsea, LLC logo" width={220} height={90} className="h-14 w-auto object-contain" />
        </a>
        <a href="/" className="inline-flex items-center gap-2 rounded-full border border-rose-gold/45 bg-card/70 px-5 py-3 text-sm font-extrabold text-foreground shadow-gold backdrop-blur transition-colors hover:bg-champagne">
          <ArrowLeft className="h-4 w-4" /> Home
        </a>
      </nav>

      <section className="mx-auto flex max-w-5xl flex-col items-center py-16 text-center md:py-24">
        <p className="text-sm font-extrabold uppercase tracking-[0.18em] text-rose-gold">Contact Chelsea</p>
        <h1 className="mt-4 max-w-4xl text-5xl font-extrabold leading-tight text-foreground sm:text-6xl lg:text-7xl">
          Contact me today.
        </h1>
        <p className="mt-6 max-w-2xl text-lg leading-8 text-muted-foreground">
          Have a question or ready to plan your visit? Call or text Chelsea directly and she will help you take the next step.
        </p>

        <div className="mt-10 grid w-full max-w-3xl gap-5 sm:grid-cols-2">
          <a
            href={`tel:+1${phoneNumber}`}
            className="group rounded-[2rem] border border-border/80 bg-card/82 p-8 text-left shadow-rose backdrop-blur transition-transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
            aria-label={`Call Chelsea at ${displayPhone}`}
          >
            <span className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-full bg-blush text-primary transition-transform group-hover:scale-110">
              <Phone className="h-7 w-7" />
            </span>
            <span className="block text-3xl font-bold text-foreground">Call Chelsea</span>
            <span className="mt-3 block text-lg font-extrabold text-primary">{displayPhone}</span>
          </a>

          <a
            href={`sms:+1${phoneNumber}`}
            className="group rounded-[2rem] border border-border/80 bg-card/82 p-8 text-left shadow-rose backdrop-blur transition-transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
            aria-label={`Text Chelsea at ${displayPhone}`}
          >
            <span className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-full bg-blush text-primary transition-transform group-hover:scale-110">
              <MessageCircle className="h-7 w-7" />
            </span>
            <span className="block text-3xl font-bold text-foreground">Text Chelsea</span>
            <span className="mt-3 block text-lg font-extrabold text-primary">{displayPhone}</span>
          </a>
        </div>
      </section>
    </main>
  );
};

export default Contact;