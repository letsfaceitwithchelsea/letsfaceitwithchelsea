import { ArrowLeft, ArrowRight } from "lucide-react";
import logoImage from "@/assets/lets-face-it-logo-transparent.png";
import semaMonthly from "@/assets/pricing/semaglutide-monthly.png";
import tirzMonthly from "@/assets/pricing/tirzepatide-monthly.png";
import retaMonthly from "@/assets/pricing/retatrutide-monthly.png";
import semaHallandale from "@/assets/pricing/semaglutide-hallandale-vial.png";
import semaEmpower from "@/assets/pricing/semaglutide-empower-vial.png";
import tirzHallandale from "@/assets/pricing/tirzepatide-hallandale-vial.png";
import tirzEmpower from "@/assets/pricing/tirzepatide-empower-vial.png";
import peptides from "@/assets/pricing/peptides-weight-management.png";

const bookingUrl = "https://book.carepatron.com/Chelsea-Phelps/Chelsea?p=J3MAp6dKQOOac1MEOTmG-g&s=9cwvkGGN";

const sections = [
  {
    heading: "Monthly Dosing & Cost",
    description: "Weekly dosing schedules and monthly pricing for medical weight management.",
    items: [
      { src: semaMonthly, alt: "Semaglutide weekly dosing and monthly cost schedule" },
      { src: tirzMonthly, alt: "Tirzepatide weekly dosing and monthly cost schedule" },
      { src: retaMonthly, alt: "Retatrutide weekly dosing and monthly cost schedule" },
    ],
  },
  {
    heading: "Vial Pricing",
    description: "Pharmacy vial concentrations, dosing, and per-vial pricing.",
    items: [
      { src: semaHallandale, alt: "Semaglutide vial pricing — Hallandale Pharmacy" },
      { src: semaEmpower, alt: "Semaglutide + B12 vial pricing — Empower Pharmacy" },
      { src: tirzHallandale, alt: "Tirzepatide vial pricing — Hallandale Pharmacy" },
      { src: tirzEmpower, alt: "Tirzepatide + Niacinamide vial pricing — Hallandale Pharmacy" },
    ],
  },
  {
    heading: "Peptide Protocols",
    description: "Metabolism support peptides with dosing and monthly pricing.",
    items: [{ src: peptides, alt: "Peptide metabolism support dosing and pricing" }],
  },
];

const Pricing = () => {
  return (
    <main className="min-h-screen bg-soft-gradient">
      <nav className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3 lg:px-8">
          <a href="/" className="flex items-center gap-3" aria-label="Let's Face It With Chelsea home">
            <img src={logoImage} alt="Let's Face It With Chelsea, LLC logo" className="h-12 w-auto object-contain sm:h-16" />
          </a>
          <a
            href={bookingUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-extrabold text-primary-foreground shadow-gold transition-transform hover:-translate-y-0.5"
          >
            Book <ArrowRight className="h-4 w-4" />
          </a>
        </div>
      </nav>

      <section className="px-5 pb-16 pt-32 lg:px-8">
        <div className="mx-auto max-w-6xl">
          <a href="/" className="inline-flex items-center gap-2 text-sm font-bold text-primary hover:underline">
            <ArrowLeft className="h-4 w-4" /> Back to home
          </a>
          <header className="mt-6 max-w-3xl">
            <p className="text-sm font-extrabold uppercase tracking-[0.18em] text-rose-gold">Pricing</p>
            <h1 className="mt-3 font-semibold text-foreground text-4xl sm:text-5xl">Transparent pricing for every protocol.</h1>
            <p className="mt-5 text-base leading-8 text-muted-foreground">
              Below you&apos;ll find current dosing schedules and pricing for our medical weight loss, vial, and peptide options. Pricing may vary based on personalized clinical recommendations during your consultation.
            </p>
          </header>

          <div className="mt-14 space-y-16">
            {sections.map((section) => (
              <div key={section.heading}>
                <div className="mb-6 max-w-2xl">
                  <h2 className="text-3xl font-semibold text-foreground sm:text-4xl">{section.heading}</h2>
                  <p className="mt-2 text-sm leading-7 text-muted-foreground">{section.description}</p>
                </div>
                <div className="grid gap-6 md:grid-cols-2">
                  {section.items.map((item) => (
                    <figure
                      key={item.src}
                      className="overflow-hidden rounded-xl border border-border/70 bg-card/86 p-3 shadow-gold backdrop-blur"
                    >
                      <img src={item.src} alt={item.alt} loading="lazy" className="h-auto w-full rounded-lg object-contain" />
                    </figure>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <div className="mt-16 rounded-[1.5rem] border border-rose-gold/30 bg-card/88 p-8 text-center shadow-rose backdrop-blur md:p-12">
            <h2 className="text-3xl font-semibold text-foreground sm:text-4xl">Ready to get started?</h2>
            <p className="mx-auto mt-4 max-w-2xl text-base leading-8 text-muted-foreground">
              Book a complimentary consultation and Chelsea will help you choose the right protocol for your goals.
            </p>
            <a
              href={bookingUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-rose-gradient px-8 py-4 text-base font-extrabold text-primary-foreground shadow-gold transition-transform hover:-translate-y-1"
            >
              Book with Chelsea <ArrowRight className="h-5 w-5" />
            </a>
          </div>
        </div>
      </section>

      <footer className="border-t border-border/70 px-5 py-8 text-center text-sm text-muted-foreground lg:px-8">
        <p>© 2026 Let&apos;s Face It With Chelsea, LLC · Greenwood, Missouri</p>
      </footer>
    </main>
  );
};

export default Pricing;
