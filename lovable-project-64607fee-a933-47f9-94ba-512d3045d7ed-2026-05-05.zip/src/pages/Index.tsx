import { ArrowRight, Award, CalendarCheck, Car, Eye, HeartPulse, MapPin, PartyPopper, Sparkles, Syringe, Waves } from "lucide-react";
import heroImage from "@/assets/chelsea-aesthetic-vials-syringes-hero.jpg";
import chelseaHeadshot from "@/assets/chelsea-headshot-cropped.jpg";
import logoImage from "@/assets/lets-face-it-logo-transparent.png";

const bookingUrl = "https://book.carepatron.com/Chelsea-Phelps/Chelsea?p=J3MAp6dKQOOac1MEOTmG-g&s=9cwvkGGN";

const services = [
  {
    icon: Syringe,
    title: "Neurotoxins",
    copy: "Botox and Dysport treatments designed for soft, refreshed results.",
  },
  {
    icon: Sparkles,
    title: "Dermal Fillers",
    copy: "Restylane and Juvederm options for natural-looking contour and volume.",
  },
  {
    icon: HeartPulse,
    title: "Medical Weight Loss",
    copy: "Supportive management plans with a clinical, wellness-centered approach.",
  },
  {
    icon: Waves,
    title: "IV Hydration & Recovery",
    copy: "In-home hydration support for recovery, replenishment, and busy schedules.",
  },
  {
    icon: Sparkles,
    title: "Peptide Protocols",
    copy: "Personalized wellness protocols developed around your goals and clinical needs.",
  },
  {
    icon: Sparkles,
    title: "Chemical Peels",
    copy: "ViPeel treatments suitable for all skin types to support smoother tone, texture, and glow.",
  },
  {
    icon: Eye,
    title: "Upneeq",
    copy: "Authorized distributor of Upneeq — the prescription eye drop that lifts droopy upper eyelids.",
    href: "https://www.upneeq.com/why-upneeq",
    cta: "View product",
  },
  {
    icon: Eye,
    title: "Latisse",
    copy: "Authorized distributor of Latisse — the prescription treatment for fuller, longer, darker lashes.",
    href: "https://www.latisse.com/",
    cta: "View product",
  },
];

const wellness = ["Free consultations", "Peptide wellness protocols", "Mobile visits", "Large party discounts"];

const Index = () => {
  return (
    <main className="min-h-screen overflow-hidden bg-soft-gradient">
      <nav className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-background/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3 lg:px-8">
          <a href="#top" className="flex items-center gap-3" aria-label="Let's Face It With Chelsea home">
            <img src={logoImage} alt="Let's Face It With Chelsea, LLC logo" width={220} height={90} className="h-12 w-auto object-contain sm:h-16" />
          </a>
          <div className="lf-nav-links hidden items-center text-sm font-semibold text-muted-foreground md:flex">
            <a className="transition-colors hover:text-primary" href="#services">Services</a>
            <a className="transition-colors hover:text-primary" href="#mobile">Mobile Care</a>
            <a className="transition-colors hover:text-primary" href="#consult">Consultation</a>
            <a className="transition-colors hover:text-primary" href="/pricing">Pricing</a>
            <a className="transition-colors hover:text-primary" href="/intake-forms">Intake Forms</a>
            <a className="transition-colors hover:text-primary" href="/contact">Contact Me Today</a>
          </div>
          <a
            href={bookingUrl}
            target="_blank"
            rel="noreferrer"
            className="group inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-extrabold text-primary-foreground shadow-gold transition-transform hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
          >
            Book <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
          </a>
        </div>
      </nav>

      <section id="top" className="lf-hero relative bg-hero-gradient">
        <div className="lf-hero-grid">
          <div className="animate-reveal">
            <img
              src={logoImage}
              alt="Let's Face It With Chelsea, LLC logo"
              width={320}
              height={130}
              className="mb-8 h-24 w-auto object-contain sm:h-28"
            />
            <div className="mb-5 flex flex-wrap gap-3">
              <p className="inline-flex items-center gap-2 rounded-full border border-rose-gold/35 bg-card/75 px-4 py-2 text-sm font-bold text-primary shadow-gold backdrop-blur">
                <MapPin className="h-4 w-4" /> Greenwood, MO + mobile care
              </p>
              <p className="inline-flex items-center gap-2 rounded-full border border-rose-gold/35 bg-card/75 px-4 py-2 text-sm font-bold text-foreground shadow-gold backdrop-blur">
                <Award className="h-4 w-4 text-primary" /> Board certified NP
              </p>
            </div>
            <h1 className="lf-title max-w-4xl font-semibold text-foreground">
              Elevated aesthetic care, delivered beautifully.
            </h1>
            <blockquote className="mt-6 max-w-2xl border-l-2 border-primary pl-5 text-lg font-semibold leading-8 text-foreground sm:text-xl">
              “Because feeling your best should be part science, part magic. It would be my pleasure to offer you both.”
            </blockquote>
            <p className="mt-6 max-w-2xl text-base leading-8 text-muted-foreground sm:text-lg">
              Let&apos;s Face It With Chelsea, LLC brings nurse practitioner-led aesthetic and wellness services to your space — from injectables to IV recovery and personalized protocols.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a
                href={bookingUrl}
                target="_blank"
                rel="noreferrer"
                className="group inline-flex items-center justify-center gap-2 rounded-full bg-rose-gradient px-7 py-4 text-base font-extrabold text-primary-foreground shadow-rose transition-transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
              >
                Schedule a free consultation <CalendarCheck className="h-5 w-5 transition-transform group-hover:rotate-6" />
              </a>
              <a
                href="#services"
                className="inline-flex items-center justify-center rounded-full border border-rose-gold/45 bg-card/60 px-7 py-4 text-base font-extrabold text-foreground backdrop-blur transition-colors hover:bg-champagne focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
              >
                Explore services
              </a>
            </div>
          </div>

          <div className="relative animate-reveal [animation-delay:180ms]">
            <img
              src={heroImage}
              alt="Rose gold aesthetic tray with wellness vials and pink flowers"
              width={1600}
              height={1100}
              className="relative z-10 aspect-[1.03] w-full rounded-[1.5rem] object-cover shadow-rose ring-1 ring-rose-gold/25"
            />
            <div className="absolute -bottom-6 left-5 right-5 z-20 rounded-xl border border-border/75 bg-card/90 p-5 shadow-gold backdrop-blur-xl sm:left-auto sm:w-72">
              <p className="text-sm font-extrabold text-primary">In-home aesthetic parties</p>
              <p className="mt-1 text-sm leading-6 text-muted-foreground">Discounts available for large parties, bridal groups, and wellness gatherings.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="services" className="px-5 py-20 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="mx-auto max-w-3xl text-center">
            <p className="text-sm font-extrabold uppercase tracking-[0.18em] text-rose-gold">Signature services</p>
            <h2 className="mt-3 text-4xl font-semibold text-foreground sm:text-5xl">Aesthetic medicine with a soft, clinical touch.</h2>
          </div>
          <div className="mt-10 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <a
                key={service.title}
                href={service.href ?? bookingUrl}
                target="_blank"
                rel="noreferrer"
                aria-label={service.href ? `View ${service.title} product details` : `Book ${service.title} with Let's Face It With Chelsea`}
                className="group block rounded-xl border border-border/70 bg-card/86 p-7 shadow-gold backdrop-blur transition-transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
              >
                <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-full bg-secondary text-primary transition-transform group-hover:scale-110">
                  <service.icon className="h-6 w-6" />
                </div>
                <h3 className="text-2xl font-semibold text-foreground">{service.title}</h3>
                <p className="mt-3 text-sm leading-7 text-muted-foreground">{service.copy}</p>
                <span className="mt-5 inline-flex items-center gap-2 text-sm font-extrabold text-primary">
                  {service.cta ?? "Book this service"} <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </a>
            ))}
          </div>
        </div>
      </section>

      <section id="mobile" className="bg-primary px-5 py-20 text-primary-foreground lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[0.85fr_1fr] lg:items-center">
          <div>
            <p className="inline-flex items-center gap-2 rounded-full bg-primary-foreground/12 px-4 py-2 text-sm font-bold"><Car className="h-4 w-4" /> Concierge care</p>
            <h2 className="mt-5 text-4xl font-semibold sm:text-5xl">Chelsea travels, so your glow fits your life.</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {wellness.map((item) => (
              <div key={item} className="rounded-xl border border-primary-foreground/18 bg-primary-foreground/10 p-5 backdrop-blur">
                <PartyPopper className="mb-4 h-6 w-6 text-champagne" />
                <p className="font-bold">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="px-5 py-20 lg:px-8">
        <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[0.82fr_1fr] lg:items-center">
          <div className="relative mx-auto max-w-md lg:mx-0">
            <img
              src={chelseaHeadshot}
              alt="Chelsea Phelps, owner of Let's Face It With Chelsea, LLC"
              width={900}
              height={1100}
              loading="lazy"
              className="relative aspect-[4/5] w-full rounded-[1.5rem] object-cover object-center shadow-rose ring-1 ring-rose-gold/30"
            />
          </div>
          <div>
            <p className="text-sm font-extrabold uppercase tracking-[0.18em] text-rose-gold">Meet Chelsea</p>
            <h2 className="mt-3 text-4xl font-semibold text-foreground sm:text-5xl">Care that feels personal, polished, and medically grounded.</h2>
            <p className="mt-5 max-w-2xl text-base leading-8 text-muted-foreground">
              As a board certified nurse practitioner, Chelsea blends clinical judgment with a warm concierge experience, helping clients feel confident whether they are booking a solo treatment, wellness support, or a group aesthetic visit.
            </p>
          </div>
        </div>
      </section>

      <section id="consult" className="px-5 py-20 lg:px-8">
        <div className="mx-auto max-w-5xl rounded-[1.5rem] border border-rose-gold/30 bg-card/88 p-8 text-center shadow-rose backdrop-blur md:p-14">
          <img src={logoImage} alt="Let's Face It With Chelsea, LLC logo" width={260} height={110} loading="lazy" className="mx-auto mb-6 h-20 w-auto object-contain" />
          <p className="text-sm font-extrabold uppercase tracking-[0.18em] text-rose-gold">Let&apos;s Face It With Chelsea, LLC</p>
          <h2 className="mt-4 text-4xl font-semibold text-foreground sm:text-5xl">Start with a complimentary consultation.</h2>
          <p className="mx-auto mt-5 max-w-2xl text-base leading-8 text-muted-foreground">
            Book online for a personalized plan covering aesthetic goals, wellness support, mobile visit details, and party availability in the Greenwood area.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <a
              href={bookingUrl}
              target="_blank"
              rel="noreferrer"
              className="group inline-flex items-center justify-center gap-2 rounded-full bg-rose-gradient px-8 py-4 text-base font-extrabold text-primary-foreground shadow-gold transition-transform hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
            >
              Book with Chelsea <ArrowRight className="h-5 w-5 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="/intake-forms"
              className="inline-flex items-center justify-center rounded-full border border-rose-gold/45 bg-card/70 px-8 py-4 text-base font-extrabold text-foreground backdrop-blur transition-colors hover:bg-champagne focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
            >
              View intake forms
            </a>
            <a
              href="/contact"
              className="inline-flex items-center justify-center rounded-full border border-rose-gold/45 bg-card/70 px-8 py-4 text-base font-extrabold text-foreground backdrop-blur transition-colors hover:bg-champagne focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 focus:ring-offset-background"
            >
              Contact me today
            </a>
          </div>
        </div>
      </section>

      <footer className="border-t border-border/70 px-5 py-8 text-center text-sm text-muted-foreground lg:px-8">
        <p>© 2026 Let&apos;s Face It With Chelsea, LLC · Mobile aesthetic and wellness services · Greenwood, Missouri</p>
      </footer>
    </main>
  );
};

export default Index;