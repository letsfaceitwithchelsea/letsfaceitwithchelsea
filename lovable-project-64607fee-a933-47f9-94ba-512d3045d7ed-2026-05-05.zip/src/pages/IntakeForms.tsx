import { ArrowLeft, Download, FileText } from "lucide-react";
import logoImage from "@/assets/lets-face-it-logo-transparent.png";

const forms = [
  {
    title: "Tirzepatide Consent Form",
    description: "Download or open the Tirzepatide consent intake form before your appointment.",
    href: "/forms/tirzepatide_consent-fillable.pdf",
  },
  {
    title: "Semaglutide Consent Form",
    description: "Download or open the Semaglutide consent intake form before your appointment.",
    href: "/forms/semaglutide_consent-fillable.pdf",
  },
  {
    title: "ViPeel Intake Form",
    description: "Download or open the ViPeel patient intake form before your chemical peel appointment.",
    href: "/forms/vi_peel_intake.pdf",
  },
  {
    title: "Dermal Filler Intake Form",
    description: "Download or open the dermal filler consent and intake form before your appointment.",
    href: "/forms/dermal_filler_intake.pdf",
  },
  {
    title: "Neurotoxin Intake Form",
    description: "Download or open the neurotoxin (Botox) consent and intake form before your appointment.",
    href: "/forms/neurotoxin_intake.pdf",
  },
];

const IntakeForms = () => {
  return (
    <main className="min-h-screen bg-soft-gradient px-5 py-8 lg:px-8">
      <nav className="mx-auto flex max-w-6xl items-center justify-between">
        <a href="/" aria-label="Back to home" className="flex items-center gap-3">
          <img src={logoImage} alt="Let's Face It With Chelsea, LLC logo" width={220} height={90} className="h-14 w-auto object-contain" />
        </a>
        <a href="/" className="inline-flex items-center gap-2 rounded-full border border-rose-gold/45 bg-card/70 px-5 py-3 text-sm font-extrabold text-foreground shadow-gold backdrop-blur transition-colors hover:bg-champagne">
          <ArrowLeft className="h-4 w-4" /> Home
        </a>
      </nav>

      <section className="mx-auto max-w-6xl py-16 md:py-24">
        <p className="text-sm font-extrabold uppercase tracking-[0.18em] text-rose-gold">Client intake</p>
        <h1 className="mt-4 max-w-4xl text-5xl font-extrabold leading-tight text-foreground sm:text-6xl lg:text-7xl">
          Intake forms for your wellness visit.
        </h1>
        <p className="mt-6 max-w-2xl text-lg leading-8 text-muted-foreground">
          Please open or download the form that applies to your treatment and complete it before your consultation or appointment.
        </p>

        <div className="mt-10 grid gap-5 md:grid-cols-2">
          {forms.map((form) => (
            <article key={form.title} className="rounded-[2rem] border border-border/80 bg-card/82 p-6 shadow-rose backdrop-blur">
              <div className="mb-6 inline-flex h-12 w-12 items-center justify-center rounded-full bg-blush text-primary">
                <FileText className="h-6 w-6" />
              </div>
              <h2 className="text-3xl font-bold text-foreground">{form.title}</h2>
              <p className="mt-3 text-sm leading-7 text-muted-foreground">{form.description}</p>
              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <a
                  href={form.href}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-full bg-rose-gradient px-6 py-3 text-sm font-extrabold text-primary-foreground shadow-gold transition-transform hover:-translate-y-0.5"
                >
                  Open form <FileText className="h-4 w-4" />
                </a>
                <a
                  href={form.href}
                  download
                  className="inline-flex items-center justify-center gap-2 rounded-full border border-rose-gold/45 bg-card/70 px-6 py-3 text-sm font-extrabold text-foreground transition-colors hover:bg-champagne"
                >
                  Download <Download className="h-4 w-4" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
};

export default IntakeForms;